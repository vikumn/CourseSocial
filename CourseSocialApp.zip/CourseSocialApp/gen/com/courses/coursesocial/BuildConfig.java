/** Automatically generated file. DO NOT MODIFY */
package com.courses.coursesocial;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}